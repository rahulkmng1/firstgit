export type ProjectStatus = 'Active' | 'Delayed' | 'Completed';
export type MilestoneStatus = 'Planned' | 'In Progress' | 'Completed' | 'Delayed';

export interface Project {
  id: string;
  title: string;
  status: ProjectStatus;
  startDate: string;
  endDate: string;
  budget: number;
  progress: number;
  category: string;
  description: string;
  impactMetrics: {
    co2Reduced: number;
    treesPlanted: number;
    energySaved: number;
    peopleImpacted: number;
  };
  budgetUsed: number;
}

export interface Milestone {
  id: string;
  title: string;
  projectId: string;
  projectName: string;
  dueDate: string;
  status: MilestoneStatus;
  notes?: string;
}

export interface Report {
  id: string;
  name: string;
  type: string;
  generatedDate: string;
  dateRange: string;
}

export const projects: Project[] = [
  {
    id: '1',
    title: 'Urban Solar Panel Installation',
    status: 'Active',
    startDate: '2025-01-15',
    endDate: '2026-06-30',
    budget: 2500000,
    progress: 68,
    category: 'Renewable Energy',
    description: 'Large-scale solar panel installation project across urban residential areas to promote renewable energy adoption and reduce carbon emissions.',
    impactMetrics: {
      co2Reduced: 1250,
      treesPlanted: 0,
      energySaved: 850000,
      peopleImpacted: 3400,
    },
    budgetUsed: 1700000,
  },
  {
    id: '2',
    title: 'Coastal Wetland Restoration',
    status: 'Delayed',
    startDate: '2024-09-01',
    endDate: '2026-08-31',
    budget: 1800000,
    progress: 42,
    category: 'Ecosystem Restoration',
    description: 'Restoration of coastal wetlands to enhance biodiversity, improve water quality, and provide natural flood protection.',
    impactMetrics: {
      co2Reduced: 890,
      treesPlanted: 0,
      energySaved: 0,
      peopleImpacted: 8500,
    },
    budgetUsed: 980000,
  },
  {
    id: '3',
    title: 'Community Reforestation Initiative',
    status: 'Active',
    startDate: '2025-03-10',
    endDate: '2027-12-15',
    budget: 950000,
    progress: 55,
    category: 'Forest Conservation',
    description: 'Community-led reforestation program to combat deforestation and restore native forest ecosystems.',
    impactMetrics: {
      co2Reduced: 2100,
      treesPlanted: 45000,
      energySaved: 0,
      peopleImpacted: 1200,
    },
    budgetUsed: 522500,
  },
  {
    id: '4',
    title: 'Zero-Waste Municipal Program',
    status: 'Completed',
    startDate: '2024-02-01',
    endDate: '2025-11-30',
    budget: 650000,
    progress: 100,
    category: 'Waste Management',
    description: 'Comprehensive waste reduction and recycling program implemented across municipal facilities.',
    impactMetrics: {
      co2Reduced: 420,
      treesPlanted: 0,
      energySaved: 125000,
      peopleImpacted: 15000,
    },
    budgetUsed: 625000,
  },
  {
    id: '5',
    title: 'Green Transportation Network',
    status: 'Active',
    startDate: '2025-05-20',
    endDate: '2027-05-20',
    budget: 3200000,
    progress: 35,
    category: 'Transportation',
    description: 'Development of bike lanes, electric bus infrastructure, and pedestrian-friendly zones to reduce transportation emissions.',
    impactMetrics: {
      co2Reduced: 560,
      treesPlanted: 0,
      energySaved: 320000,
      peopleImpacted: 28000,
    },
    budgetUsed: 1120000,
  },
  {
    id: '6',
    title: 'Agricultural Carbon Sequestration',
    status: 'Delayed',
    startDate: '2024-11-01',
    endDate: '2026-10-31',
    budget: 1400000,
    progress: 28,
    category: 'Agriculture',
    description: 'Implementation of carbon farming practices to enhance soil health and capture atmospheric carbon.',
    impactMetrics: {
      co2Reduced: 1850,
      treesPlanted: 0,
      energySaved: 0,
      peopleImpacted: 450,
    },
    budgetUsed: 392000,
  },
  {
    id: '7',
    title: 'Smart Grid Energy Optimization',
    status: 'Completed',
    startDate: '2023-06-15',
    endDate: '2025-06-15',
    budget: 2100000,
    progress: 100,
    category: 'Energy Efficiency',
    description: 'Smart grid infrastructure deployment to optimize energy distribution and reduce waste.',
    impactMetrics: {
      co2Reduced: 1680,
      treesPlanted: 0,
      energySaved: 1250000,
      peopleImpacted: 42000,
    },
    budgetUsed: 2050000,
  },
];

export const milestones: Milestone[] = [
  // Urban Solar Panel Installation
  { id: 'm1', title: 'Site Assessment Complete', projectId: '1', projectName: 'Urban Solar Panel Installation', dueDate: '2025-02-28', status: 'Completed' },
  { id: 'm2', title: 'Equipment Procurement', projectId: '1', projectName: 'Urban Solar Panel Installation', dueDate: '2025-04-30', status: 'Completed' },
  { id: 'm3', title: 'Installation Phase 1', projectId: '1', projectName: 'Urban Solar Panel Installation', dueDate: '2025-08-31', status: 'Completed' },
  { id: 'm4', title: 'Installation Phase 2', projectId: '1', projectName: 'Urban Solar Panel Installation', dueDate: '2026-02-28', status: 'In Progress' },
  { id: 'm5', title: 'Final Testing & Commissioning', projectId: '1', projectName: 'Urban Solar Panel Installation', dueDate: '2026-06-30', status: 'Planned' },
  
  // Coastal Wetland Restoration
  { id: 'm6', title: 'Environmental Impact Study', projectId: '2', projectName: 'Coastal Wetland Restoration', dueDate: '2024-11-30', status: 'Completed' },
  { id: 'm7', title: 'Land Acquisition', projectId: '2', projectName: 'Coastal Wetland Restoration', dueDate: '2025-03-31', status: 'Delayed' },
  { id: 'm8', title: 'Restoration Phase 1', projectId: '2', projectName: 'Coastal Wetland Restoration', dueDate: '2025-09-30', status: 'In Progress' },
  { id: 'm9', title: 'Biodiversity Monitoring Setup', projectId: '2', projectName: 'Coastal Wetland Restoration', dueDate: '2026-02-28', status: 'Planned' },
  
  // Community Reforestation Initiative
  { id: 'm10', title: 'Community Engagement', projectId: '3', projectName: 'Community Reforestation Initiative', dueDate: '2025-04-15', status: 'Completed' },
  { id: 'm11', title: 'Seedling Preparation', projectId: '3', projectName: 'Community Reforestation Initiative', dueDate: '2025-06-30', status: 'Completed' },
  { id: 'm12', title: 'Planting Season 1', projectId: '3', projectName: 'Community Reforestation Initiative', dueDate: '2025-12-31', status: 'In Progress' },
  { id: 'm13', title: 'Planting Season 2', projectId: '3', projectName: 'Community Reforestation Initiative', dueDate: '2026-12-31', status: 'Planned' },
  
  // Green Transportation Network
  { id: 'm14', title: 'Route Planning', projectId: '5', projectName: 'Green Transportation Network', dueDate: '2025-07-31', status: 'Completed' },
  { id: 'm15', title: 'Bike Lane Construction', projectId: '5', projectName: 'Green Transportation Network', dueDate: '2026-03-31', status: 'In Progress' },
  { id: 'm16', title: 'E-Bus Infrastructure', projectId: '5', projectName: 'Green Transportation Network', dueDate: '2026-10-31', status: 'Planned' },
  
  // Agricultural Carbon Sequestration
  { id: 'm17', title: 'Farmer Training Program', projectId: '6', projectName: 'Agricultural Carbon Sequestration', dueDate: '2025-01-31', status: 'Delayed' },
  { id: 'm18', title: 'Pilot Implementation', projectId: '6', projectName: 'Agricultural Carbon Sequestration', dueDate: '2025-06-30', status: 'In Progress' },
  { id: 'm19', title: 'Full-Scale Rollout', projectId: '6', projectName: 'Agricultural Carbon Sequestration', dueDate: '2026-04-30', status: 'Planned' },
];

export const reports: Report[] = [
  { id: 'r1', name: 'Q4 2025 Project Summary', type: 'Project Summary', generatedDate: '2025-12-31', dateRange: 'Oct 1 - Dec 31, 2025' },
  { id: 'r2', name: 'Milestone Status Report - Feb 2026', type: 'Milestone Status', generatedDate: '2026-02-28', dateRange: 'Jan 1 - Feb 28, 2026' },
  { id: 'r3', name: '2025 Annual Impact Report', type: 'Impact Report', generatedDate: '2025-12-31', dateRange: 'Jan 1 - Dec 31, 2025' },
  { id: 'r4', name: 'Budget Utilization - Q1 2026', type: 'Budget Report', generatedDate: '2026-03-01', dateRange: 'Jan 1 - Mar 1, 2026' },
];
