import { useMemo, useState } from 'react';
import { Link } from 'react-router';
import { projects } from '../data/mockData';
import { StatusBadge } from './StatusBadge';
import {
  LayoutDashboard,
  TrendingUp,
  Clock,
  CheckCircle2,
  FolderOpen,
  AlertCircle,
  User,
  MapPin,
  Plus,
  X,
} from 'lucide-react';

export function Dashboard() {
  const [showNewProjectModal, setShowNewProjectModal] = useState(false);
  const [selectedProjectNeed, setSelectedProjectNeed] = useState<number | null>(null);
  const [newProject, setNewProject] = useState({
    title: '',
    description: '',
    startDate: '',
    endDate: '',
    budget: '',
    status: 'Planning' as 'Planning' | 'Active' | 'Delayed' | 'Completed',
  });

  // Calculate KPIs
  const kpis = useMemo(() => {
    const total = projects.length;
    const active = projects.filter((p) => p.status === 'Active').length;
    const delayed = projects.filter((p) => p.status === 'Delayed').length;
    const completed = projects.filter((p) => p.status === 'Completed').length;

    return { total, active, delayed, completed };
  }, []);

  // Upcoming Project Needs/Requests
  const upcomingProjectNeeds = [
    {
      id: 1,
      projectType: 'Afforestation',
      requestedBy: 'Environmental Officer',
      officerName: 'Dr. Sarah Mitchell',
      region: 'Northern District',
      priority: 'High',
      estimatedBudget: 1500000,
      description: 'Large-scale tree plantation required to restore deforested areas',
      requestDate: '2026-03-10',
    },
    {
      id: 2,
      projectType: 'Renewable Energy',
      requestedBy: 'Resource Officer',
      officerName: 'Michael Chen',
      region: 'Coastal Region',
      priority: 'High',
      estimatedBudget: 3200000,
      description: 'Wind energy installation needed for sustainable power generation',
      requestDate: '2026-03-08',
    },
    {
      id: 3,
      projectType: 'Water Conservation',
      requestedBy: 'Environmental Officer',
      officerName: 'Dr. Sarah Mitchell',
      region: 'Central Plains',
      priority: 'Medium',
      estimatedBudget: 850000,
      description: 'Rainwater harvesting systems for agricultural areas',
      requestDate: '2026-03-05',
    },
    {
      id: 4,
      projectType: 'Renewable Energy',
      requestedBy: 'Resource Officer',
      officerName: 'Alex Rodriguez',
      region: 'Southern Highlands',
      priority: 'High',
      estimatedBudget: 2800000,
      description: 'Solar panel installation for rural electrification',
      requestDate: '2026-03-01',
    },
    {
      id: 5,
      projectType: 'Afforestation',
      requestedBy: 'Environmental Officer',
      officerName: 'Dr. Priya Sharma',
      region: 'Eastern Valleys',
      priority: 'Medium',
      estimatedBudget: 1200000,
      description: 'Native species reforestation for biodiversity enhancement',
      requestDate: '2026-02-28',
    },
  ];

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(amount);
  };

  const formatDate = (dateStr: string) => {
    return new Date(dateStr).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
    });
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'High':
        return 'bg-red-100 text-red-700 border-red-200';
      case 'Medium':
        return 'bg-yellow-100 text-yellow-700 border-yellow-200';
      case 'Low':
        return 'bg-green-100 text-green-700 border-green-200';
      default:
        return 'bg-gray-100 text-gray-700 border-gray-200';
    }
  };

  const handleOpenModal = () => {
    setShowNewProjectModal(true);
    setSelectedProjectNeed(null);
    setNewProject({
      title: '',
      description: '',
      startDate: '',
      endDate: '',
      budget: '',
      status: 'Planning',
    });
  };

  const handleSelectProjectNeed = (needId: number) => {
    const need = upcomingProjectNeeds.find((n) => n.id === needId);
    if (need) {
      setSelectedProjectNeed(needId);
      setNewProject({
        title: need.projectType + ' - ' + need.region,
        description: need.description,
        startDate: '',
        endDate: '',
        budget: need.estimatedBudget.toString(),
        status: 'Planning',
      });
    }
  };

  const handleCreateProject = (e: React.FormEvent) => {
    e.preventDefault();
    // In a real app, this would save to a database
    console.log('Creating new project:', newProject);
    alert('Project created successfully! (This is a demo - data is not persisted)');
    setShowNewProjectModal(false);
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Main Content */}
      <main className="p-8">
        {/* KPI Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <div className="bg-white rounded-lg border border-gray-200 p-6">
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm font-medium text-gray-600">Total Projects</span>
              <FolderOpen className="w-5 h-5 text-gray-400" />
            </div>
            <div className="text-3xl font-semibold text-gray-900">{kpis.total}</div>
          </div>

          <div className="bg-white rounded-lg border border-gray-200 p-6">
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm font-medium text-gray-600">Active Projects</span>
              <TrendingUp className="w-5 h-5 text-green-500" />
            </div>
            <div className="text-3xl font-semibold text-gray-900">{kpis.active}</div>
          </div>

          <div className="bg-white rounded-lg border border-gray-200 p-6">
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm font-medium text-gray-600">Delayed Projects</span>
              <Clock className="w-5 h-5 text-red-500" />
            </div>
            <div className="text-3xl font-semibold text-gray-900">{kpis.delayed}</div>
          </div>

          <div className="bg-white rounded-lg border border-gray-200 p-6">
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm font-medium text-gray-600">Completed Projects</span>
              <CheckCircle2 className="w-5 h-5 text-green-500" />
            </div>
            <div className="text-3xl font-semibold text-gray-900">{kpis.completed}</div>
          </div>
        </div>

        {/* Upcoming Project Needs Section */}
        <div className="bg-white rounded-lg border border-gray-200 mb-8">
          <div className="p-6 border-b border-gray-200">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="font-semibold text-gray-900">Upcoming Project Needs</h2>
                <p className="text-sm text-gray-600 mt-1">
                  Project requests from Environmental and Resource Officers
                </p>
              </div>
              <div className="flex items-center gap-3">
                <button
                  onClick={handleOpenModal}
                  className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
                >
                  <Plus className="w-4 h-4" />
                  <span className="text-sm font-medium">New Project</span>
                </button>
                <div className="flex items-center gap-2 px-3 py-1 bg-orange-50 border border-orange-200 rounded-lg">
                  <AlertCircle className="w-4 h-4 text-orange-600" />
                  <span className="text-sm font-medium text-orange-700">
                    {upcomingProjectNeeds.length} Pending Requests
                  </span>
                </div>
              </div>
            </div>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-gray-50 border-b border-gray-200">
                <tr>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Project Type
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Requested By
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Region
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Priority
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Request Date
                  </th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {upcomingProjectNeeds.map((need) => (
                  <tr key={need.id} className="hover:bg-gray-50">
                    <td className="px-6 py-4 whitespace-nowrap">
                      <span className="text-sm font-semibold text-gray-900">{need.projectType}</span>
                    </td>
                    <td className="px-6 py-4">
                      <div className="flex items-start">
                        <User className="w-4 h-4 text-gray-400 mr-2 mt-0.5" />
                        <div>
                          <div className="text-sm font-medium text-gray-900">{need.officerName}</div>
                          <div className="text-xs text-gray-500">{need.requestedBy}</div>
                        </div>
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="flex items-center">
                        <MapPin className="w-4 h-4 text-gray-400 mr-1" />
                        <span className="text-sm text-gray-600">{need.region}</span>
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <span
                        className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium border ${getPriorityColor(
                          need.priority
                        )}`}
                      >
                        {need.priority}
                      </span>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-600">
                      {formatDate(need.requestDate)}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Project Summary Table */}
        <div className="bg-white rounded-lg border border-gray-200">
          <div className="p-6 border-b border-gray-200">
            <h2 className="font-semibold text-gray-900">Project Summary</h2>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-gray-50 border-b border-gray-200">
                <tr>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Project Title
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Status
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Start Date
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    End Date
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Budget
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Progress
                  </th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {projects.map((project) => (
                  <tr key={project.id} className="hover:bg-gray-50">
                    <td className="px-6 py-4 whitespace-nowrap">
                      <Link
                        to={`/projects/${project.id}`}
                        className="text-sm font-medium text-blue-600 hover:text-blue-800"
                      >
                        {project.title}
                      </Link>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <StatusBadge status={project.status} size="sm" />
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-600">
                      {formatDate(project.startDate)}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-600">
                      {formatDate(project.endDate)}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-600">
                      {formatCurrency(project.budget)}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="flex items-center">
                        <div className="w-32 bg-gray-200 rounded-full h-2 mr-2">
                          <div
                            className="bg-blue-600 h-2 rounded-full"
                            style={{ width: `${project.progress}%` }}
                          ></div>
                        </div>
                        <span className="text-sm text-gray-600">{project.progress}%</span>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </main>

      {/* New Project Modal */}
      {showNewProjectModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-lg shadow-xl max-w-4xl w-full max-h-[90vh] overflow-y-auto">
            {/* Modal Header */}
            <div className="p-6 border-b border-gray-200 flex items-center justify-between sticky top-0 bg-white">
              <h2 className="text-xl font-semibold text-gray-900">Create New Project</h2>
              <button
                onClick={() => setShowNewProjectModal(false)}
                className="text-gray-400 hover:text-gray-600 transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Modal Content */}
            <div className="p-6">
              {/* Upcoming Project Needs Selection */}
              <div className="mb-6">
                <h3 className="text-sm font-medium text-gray-900 mb-3">
                  Select from Upcoming Project Needs (Optional)
                </h3>
                <div className="border border-gray-200 rounded-lg overflow-hidden">
                  <table className="w-full">
                    <thead className="bg-gray-50">
                      <tr>
                        <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase">
                          Select
                        </th>
                        <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase">
                          Project Type
                        </th>
                        <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase">
                          Requested By
                        </th>
                        <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase">
                          Region
                        </th>
                        <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase">
                          Priority
                        </th>
                      </tr>
                    </thead>
                    <tbody className="bg-white divide-y divide-gray-200">
                      {upcomingProjectNeeds.map((need) => (
                        <tr
                          key={need.id}
                          className={`cursor-pointer hover:bg-blue-50 ${
                            selectedProjectNeed === need.id ? 'bg-blue-100' : ''
                          }`}
                          onClick={() => handleSelectProjectNeed(need.id)}
                        >
                          <td className="px-4 py-3">
                            <input
                              type="radio"
                              name="projectNeed"
                              checked={selectedProjectNeed === need.id}
                              onChange={() => handleSelectProjectNeed(need.id)}
                              className="w-4 h-4 text-blue-600 cursor-pointer"
                            />
                          </td>
                          <td className="px-4 py-3 text-sm font-medium text-gray-900">
                            {need.projectType}
                          </td>
                          <td className="px-4 py-3">
                            <div className="text-sm font-medium text-gray-900">
                              {need.officerName}
                            </div>
                            <div className="text-xs text-gray-500">{need.requestedBy}</div>
                          </td>
                          <td className="px-4 py-3 text-sm text-gray-600">{need.region}</td>
                          <td className="px-4 py-3">
                            <span
                              className={`inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium border ${getPriorityColor(
                                need.priority
                              )}`}
                            >
                              {need.priority}
                            </span>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>

              {/* New Project Form */}
              <form onSubmit={handleCreateProject}>
                <div className="border-t border-gray-200 pt-6">
                  <h3 className="text-sm font-medium text-gray-900 mb-4">Project Details</h3>
                  <div className="grid grid-cols-1 gap-4">
                    {/* Title */}
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">
                        Project Title <span className="text-red-500">*</span>
                      </label>
                      <input
                        type="text"
                        required
                        value={newProject.title}
                        onChange={(e) =>
                          setNewProject({ ...newProject, title: e.target.value })
                        }
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                        placeholder="Enter project title"
                      />
                    </div>

                    {/* Description */}
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">
                        Description <span className="text-red-500">*</span>
                      </label>
                      <textarea
                        required
                        value={newProject.description}
                        onChange={(e) =>
                          setNewProject({ ...newProject, description: e.target.value })
                        }
                        rows={4}
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                        placeholder="Enter project description"
                      />
                    </div>

                    {/* Dates */}
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">
                          Start Date <span className="text-red-500">*</span>
                        </label>
                        <input
                          type="date"
                          required
                          value={newProject.startDate}
                          onChange={(e) =>
                            setNewProject({ ...newProject, startDate: e.target.value })
                          }
                          className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">
                          End Date <span className="text-red-500">*</span>
                        </label>
                        <input
                          type="date"
                          required
                          value={newProject.endDate}
                          onChange={(e) =>
                            setNewProject({ ...newProject, endDate: e.target.value })
                          }
                          className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                        />
                      </div>
                    </div>

                    {/* Budget and Status */}
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">
                          Budget <span className="text-red-500">*</span>
                        </label>
                        <input
                          type="number"
                          required
                          value={newProject.budget}
                          onChange={(e) =>
                            setNewProject({ ...newProject, budget: e.target.value })
                          }
                          className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                          placeholder="Enter budget amount"
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">
                          Status <span className="text-red-500">*</span>
                        </label>
                        <select
                          required
                          value={newProject.status}
                          onChange={(e) =>
                            setNewProject({
                              ...newProject,
                              status: e.target.value as any,
                            })
                          }
                          className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                        >
                          <option value="Planning">Planning</option>
                          <option value="Active">Active</option>
                          <option value="Delayed">Delayed</option>
                          <option value="Completed">Completed</option>
                        </select>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Modal Footer */}
                <div className="mt-6 flex items-center justify-end gap-3">
                  <button
                    type="button"
                    onClick={() => setShowNewProjectModal(false)}
                    className="px-4 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50 transition-colors"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
                  >
                    Create Project
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}