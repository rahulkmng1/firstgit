import { projects } from '../data/mockData';
import { Leaf, Zap, Trees, Users } from 'lucide-react';

export function Impact() {
  // Calculate overall impact metrics from all projects
  const totalImpact = {
    co2Reduced: 3450, // tons
    treesPlanted: 125000,
    energySaved: 2500000, // kWh
    peopleImpacted: 15400,
  };

  // Project-wise impact breakdown
  const projectImpacts = [
    {
      id: 1,
      projectName: 'Urban Solar Panel Installation',
      co2Reduced: 1250,
      treesPlanted: 0,
      energySaved: 850000,
      waterConserved: 0,
      peopleImpacted: 3400,
    },
    {
      id: 2,
      projectName: 'Wetland Restoration Initiative',
      co2Reduced: 890,
      treesPlanted: 15000,
      energySaved: 0,
      waterConserved: 450000,
      peopleImpacted: 2800,
    },
    {
      id: 3,
      projectName: 'Reforestation Program',
      co2Reduced: 1310,
      treesPlanted: 110000,
      energySaved: 0,
      waterConserved: 400000,
      peopleImpacted: 9200,
    },
  ];

  return (
    <div className="min-h-screen bg-gray-50 p-8">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-semibold text-gray-900 mb-2">Environmental Impact Dashboard</h1>
          <p className="text-gray-600">Cumulative impact of all climate action projects</p>
        </div>

        {/* Overall Impact Metrics */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          {/* CO2 Reduced */}
          <div className="bg-gradient-to-br from-green-50 to-emerald-50 rounded-lg border border-green-200 p-6">
            <div className="flex items-center justify-between mb-3">
              <Leaf className="w-8 h-8 text-green-600" />
              <div className="px-3 py-1 bg-green-100 text-green-700 text-xs font-semibold rounded-full">
                +12% vs last year
              </div>
            </div>
            <div className="text-3xl font-bold text-gray-900 mb-1">
              {totalImpact.co2Reduced.toLocaleString()}
            </div>
            <div className="text-sm text-gray-600">Tons CO₂ Reduced</div>
          </div>

          {/* Trees Planted */}
          <div className="bg-gradient-to-br from-emerald-50 to-green-50 rounded-lg border border-emerald-200 p-6">
            <div className="flex items-center justify-between mb-3">
              <Trees className="w-8 h-8 text-emerald-600" />
              <div className="px-3 py-1 bg-emerald-100 text-emerald-700 text-xs font-semibold rounded-full">
                Target: 150K
              </div>
            </div>
            <div className="text-3xl font-bold text-gray-900 mb-1">
              {(totalImpact.treesPlanted / 1000).toFixed(0)}K
            </div>
            <div className="text-sm text-gray-600">Trees Planted</div>
          </div>

          {/* Energy Saved */}
          <div className="bg-gradient-to-br from-yellow-50 to-amber-50 rounded-lg border border-yellow-200 p-6">
            <div className="flex items-center justify-between mb-3">
              <Zap className="w-8 h-8 text-yellow-600" />
              <div className="px-3 py-1 bg-yellow-100 text-yellow-700 text-xs font-semibold rounded-full">
                +25% growth
              </div>
            </div>
            <div className="text-3xl font-bold text-gray-900 mb-1">
              {(totalImpact.energySaved / 1000000).toFixed(1)}M
            </div>
            <div className="text-sm text-gray-600">kWh Energy Saved</div>
          </div>

          {/* People Impacted */}
          <div className="bg-gradient-to-br from-blue-50 to-indigo-50 rounded-lg border border-blue-200 p-6">
            <div className="flex items-center justify-between mb-3">
              <Users className="w-8 h-8 text-blue-600" />
              <div className="px-3 py-1 bg-blue-100 text-blue-700 text-xs font-semibold rounded-full">
                15 communities
              </div>
            </div>
            <div className="text-3xl font-bold text-gray-900 mb-1">
              {(totalImpact.peopleImpacted / 1000).toFixed(1)}K
            </div>
            <div className="text-sm text-gray-600">People Benefited</div>
          </div>
        </div>

        {/* Project-wise Impact Breakdown */}
        <div className="bg-white rounded-lg border border-gray-200 mb-8">
          <div className="p-6 border-b border-gray-200">
            <h2 className="text-lg font-semibold text-gray-900">Project-wise Impact Analysis</h2>
            <p className="text-sm text-gray-600 mt-1">Detailed environmental impact by individual projects</p>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-gray-50 border-b border-gray-200">
                <tr>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Project Name
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    CO₂ Reduced (tons)
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Trees Planted
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Energy Saved (kWh)
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Water Saved (L)
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    People Impacted
                  </th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {projectImpacts.map((project) => (
                  <tr key={project.id} className="hover:bg-gray-50">
                    <td className="px-6 py-4">
                      <div className="text-sm font-medium text-gray-900">{project.projectName}</div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="flex items-center">
                        <Leaf className="w-4 h-4 text-green-500 mr-2" />
                        <span className="text-sm text-gray-900 font-semibold">
                          {project.co2Reduced.toLocaleString()}
                        </span>
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="flex items-center">
                        <Trees className="w-4 h-4 text-emerald-500 mr-2" />
                        <span className="text-sm text-gray-900">
                          {project.treesPlanted > 0 ? project.treesPlanted.toLocaleString() : '-'}
                        </span>
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="flex items-center">
                        <Zap className="w-4 h-4 text-yellow-500 mr-2" />
                        <span className="text-sm text-gray-900">
                          {project.energySaved > 0 ? project.energySaved.toLocaleString() : '-'}
                        </span>
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="flex items-center">
                        <Leaf className="w-4 h-4 text-green-500 mr-2" />
                        <span className="text-sm text-gray-900">
                          {project.waterConserved > 0 ? project.waterConserved.toLocaleString() : '-'}
                        </span>
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="flex items-center">
                        <Users className="w-4 h-4 text-blue-500 mr-2" />
                        <span className="text-sm text-gray-900">
                          {project.peopleImpacted.toLocaleString()}
                        </span>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Impact Visualization */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Carbon Footprint Reduction */}
          <div className="bg-white rounded-lg border border-gray-200 p-6">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">Carbon Footprint Reduction</h3>
            <div className="space-y-4">
              {projectImpacts.map((project) => (
                <div key={project.id}>
                  <div className="flex justify-between items-center mb-1">
                    <span className="text-sm text-gray-700">{project.projectName}</span>
                    <span className="text-sm font-semibold text-gray-900">{project.co2Reduced} tons</span>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-2">
                    <div
                      className="bg-green-600 h-2 rounded-full"
                      style={{ width: `${(project.co2Reduced / totalImpact.co2Reduced) * 100}%` }}
                    ></div>
                  </div>
                </div>
              ))}
            </div>
            <div className="mt-6 pt-4 border-t border-gray-200">
              <div className="flex justify-between items-center">
                <span className="text-sm font-semibold text-gray-700">Total CO₂ Reduction:</span>
                <span className="text-lg font-bold text-green-600">{totalImpact.co2Reduced} tons</span>
              </div>
            </div>
          </div>

          {/* Community Reach */}
          <div className="bg-white rounded-lg border border-gray-200 p-6">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">Community Reach</h3>
            <div className="space-y-4">
              {projectImpacts.map((project) => (
                <div key={project.id}>
                  <div className="flex justify-between items-center mb-1">
                    <span className="text-sm text-gray-700">{project.projectName}</span>
                    <span className="text-sm font-semibold text-gray-900">
                      {project.peopleImpacted.toLocaleString()} people
                    </span>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-2">
                    <div
                      className="bg-blue-600 h-2 rounded-full"
                      style={{ width: `${(project.peopleImpacted / totalImpact.peopleImpacted) * 100}%` }}
                    ></div>
                  </div>
                </div>
              ))}
            </div>
            <div className="mt-6 pt-4 border-t border-gray-200">
              <div className="flex justify-between items-center">
                <span className="text-sm font-semibold text-gray-700">Total People Benefited:</span>
                <span className="text-lg font-bold text-blue-600">
                  {totalImpact.peopleImpacted.toLocaleString()}
                </span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}