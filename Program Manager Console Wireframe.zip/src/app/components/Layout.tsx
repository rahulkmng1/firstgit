import { Link, Outlet, useLocation } from 'react-router';
import { LayoutDashboard, Target, TrendingUp, Bell, User, LogOut } from 'lucide-react';
import { useState } from 'react';

export function Layout() {
  const location = useLocation();
  const [showNotifications, setShowNotifications] = useState(false);
  const [showUserMenu, setShowUserMenu] = useState(false);

  const isActive = (path: string) => {
    if (path === '/') {
      return location.pathname === '/' || location.pathname.startsWith('/projects/');
    }
    return location.pathname.startsWith(path);
  };

  const navItems = [
    { path: '/', label: 'Dashboard', icon: LayoutDashboard },
    { path: '/milestones', label: 'Milestones', icon: Target },
    { path: '/impact', label: 'Impact', icon: TrendingUp },
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Top Navigation Bar */}
      <nav className="bg-white border-b border-gray-200">
        <div className="px-8">
          <div className="flex items-center justify-between h-16">
            {/* Logo/Title */}
            <div className="flex items-center">
              <h1 className="text-xl font-semibold text-gray-900">
                Environmental Climate Action System
              </h1>
            </div>

            <div className="flex items-center gap-8">
              {/* Navigation Tabs */}
              <div className="flex space-x-1">
                {navItems.map((item) => {
                  const Icon = item.icon;
                  const active = isActive(item.path);
                  return (
                    <Link
                      key={item.path}
                      to={item.path}
                      className={`inline-flex items-center px-4 py-2 border-b-2 text-sm font-medium transition-colors ${
                        active
                          ? 'border-blue-600 text-blue-600'
                          : 'border-transparent text-gray-600 hover:text-gray-900 hover:border-gray-300'
                      }`}
                    >
                      <Icon className="w-4 h-4 mr-2" />
                      {item.label}
                    </Link>
                  );
                })}
              </div>

              {/* Right Side: Notifications & User */}
              <div className="flex items-center gap-4">
                {/* Notification Bell */}
                <div className="relative">
                  <button
                    onClick={() => {
                      setShowNotifications(!showNotifications);
                      setShowUserMenu(false);
                    }}
                    className="relative p-2 text-gray-600 hover:text-gray-900 hover:bg-gray-100 rounded-full transition-colors"
                  >
                    <Bell className="w-5 h-5" />
                    {/* Notification Badge */}
                    <span className="absolute top-1 right-1 w-2 h-2 bg-red-500 rounded-full"></span>
                  </button>

                  {/* Notification Dropdown */}
                  {showNotifications && <NotificationPanel currentPath={location.pathname} />}
                </div>

                {/* User Profile */}
                <div className="relative">
                  <button
                    onClick={() => {
                      setShowUserMenu(!showUserMenu);
                      setShowNotifications(false);
                    }}
                    className="flex items-center gap-2 p-2 text-gray-700 hover:bg-gray-100 rounded-lg transition-colors"
                  >
                    <div className="w-8 h-8 bg-blue-600 rounded-full flex items-center justify-center">
                      <User className="w-5 h-5 text-white" />
                    </div>
                    <div className="text-left">
                      <div className="text-sm font-medium">John Anderson</div>
                      <div className="text-xs text-gray-500">Program Manager</div>
                    </div>
                  </button>

                  {/* User Dropdown Menu */}
                  {showUserMenu && (
                    <div className="absolute right-0 mt-2 w-56 bg-white rounded-lg shadow-lg border border-gray-200 py-2 z-50">
                      <div className="px-4 py-2 border-b border-gray-200">
                        <div className="text-sm font-medium text-gray-900">John Anderson</div>
                        <div className="text-xs text-gray-500">john.anderson@climate.org</div>
                      </div>
                      <button
                        onClick={() => alert('Logout functionality')}
                        className="w-full px-4 py-2 text-left text-sm text-red-600 hover:bg-red-50 flex items-center gap-2"
                      >
                        <LogOut className="w-4 h-4" />
                        Logout
                      </button>
                    </div>
                  )}
                </div>
              </div>
            </div>
          </div>
        </div>
      </nav>

      {/* Main Content */}
      <Outlet />
    </div>
  );
}

// Notification Panel Component
function NotificationPanel({ currentPath }: { currentPath: string }) {
  const getNotifications = () => {
    if (currentPath.startsWith('/milestones')) {
      return [
        {
          id: 1,
          title: 'Milestone Delay Alert',
          description: 'Site Assessment milestone for Wetland Restoration project is delayed by 15 days.',
          findings: 'Auditor found inadequate documentation for land acquisition permits. Immediate action required to avoid compliance issues.',
          time: '2 hours ago',
          type: 'complaint',
        },
        {
          id: 2,
          title: 'Compliance Issue',
          description: 'Equipment Procurement milestone lacks required environmental impact assessment.',
          findings: 'Missing EIA reports for solar panel procurement. Must be submitted within 5 business days per regulatory requirements.',
          time: '5 hours ago',
          type: 'complaint',
        },
        {
          id: 3,
          title: 'Audit Observation',
          description: 'Community Engagement milestone timeline discrepancy identified.',
          findings: 'Planned dates do not align with stakeholder consultation requirements outlined in project charter.',
          time: '1 day ago',
          type: 'complaint',
        },
      ];
    } else if (currentPath.startsWith('/impact')) {
      return [
        {
          id: 1,
          title: 'Budget Report Discrepancy',
          description: 'Q4 2025 Budget Report shows unexplained variance in operational costs.',
          findings: 'Auditor identified $45,000 discrepancy between reported and allocated budget. Requires detailed cost breakdown and justification.',
          time: '3 hours ago',
          type: 'complaint',
        },
        {
          id: 2,
          title: 'Impact Report Incomplete',
          description: 'Annual Impact Report missing carbon offset verification documents.',
          findings: 'Third-party verification certificates for CO2 reduction claims are not attached. Report cannot be published without proper validation.',
          time: '6 hours ago',
          type: 'complaint',
        },
        {
          id: 3,
          title: 'Data Validation Error',
          description: 'Milestone Status Report contains inconsistent completion percentages.',
          findings: 'Manual review shows 12% discrepancy between automated calculations and field data. Data integrity check needed.',
          time: '2 days ago',
          type: 'complaint',
        },
      ];
    } else {
      // Dashboard or Project Detail
      return [
        {
          id: 1,
          title: 'Project Budget Compliance Alert',
          description: 'Solar Panel Installation project exceeded quarterly budget allocation by 8%.',
          findings: 'Auditor flagged unapproved vendor payments totaling $125,000. Requires budget reallocation approval and vendor contract review.',
          time: '1 hour ago',
          type: 'complaint',
        },
        {
          id: 2,
          title: 'Documentation Gap',
          description: 'Wetland Restoration project missing required environmental permits.',
          findings: 'State wetland protection permits not found in project repository. Project activities must halt until permits are uploaded and verified.',
          time: '4 hours ago',
          type: 'complaint',
        },
        {
          id: 3,
          title: 'Timeline Non-Compliance',
          description: 'Reforestation Initiative not meeting quarterly planting targets.',
          findings: 'Only 65% of planned tree planting completed. Audit shows resource allocation issues and contractor performance concerns.',
          time: '1 day ago',
          type: 'complaint',
        },
      ];
    }
  };

  const notifications = getNotifications();

  return (
    <div className="absolute right-0 mt-2 w-96 bg-white rounded-lg shadow-lg border border-gray-200 z-50 max-h-[500px] overflow-hidden flex flex-col">
      <div className="px-4 py-3 border-b border-gray-200 bg-gray-50">
        <h3 className="text-sm font-semibold text-gray-900">Auditor Complaints & Alerts</h3>
      </div>
      <div className="overflow-y-auto">
        {notifications.map((notification) => (
          <NotificationItem key={notification.id} notification={notification} />
        ))}
      </div>
    </div>
  );
}

function NotificationItem({ notification }: { notification: any }) {
  const [expanded, setExpanded] = useState(false);

  return (
    <div className="border-b border-gray-200 hover:bg-gray-50">
      <button
        onClick={() => setExpanded(!expanded)}
        className="w-full px-4 py-3 text-left"
      >
        <div className="flex items-start justify-between gap-2">
          <div className="flex-1">
            <div className="flex items-center gap-2 mb-1">
              <span className="w-2 h-2 bg-red-500 rounded-full"></span>
              <h4 className="text-sm font-medium text-gray-900">{notification.title}</h4>
            </div>
            <p className="text-xs text-gray-600">{notification.description}</p>
            <p className="text-xs text-gray-400 mt-1">{notification.time}</p>
          </div>
          <svg
            className={`w-4 h-4 text-gray-400 transition-transform ${expanded ? 'rotate-180' : ''}`}
            fill="none"
            stroke="currentColor"
            viewBox="0 0 24 24"
          >
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
          </svg>
        </div>
      </button>

      {expanded && (
        <div className="px-4 pb-3 bg-red-50 border-t border-red-100">
          <div className="text-xs font-semibold text-gray-700 mb-1">Findings:</div>
          <p className="text-xs text-gray-800">{notification.findings}</p>
        </div>
      )}
    </div>
  );
}