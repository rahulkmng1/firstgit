import { useParams, Link } from 'react-router';
import { projects, milestones } from '../data/mockData';
import { StatusBadge } from './StatusBadge';
import { ArrowLeft, Calendar, DollarSign, Leaf, Users, Zap, TreePine } from 'lucide-react';
import { PieChart, Pie, Cell, ResponsiveContainer, Legend, Tooltip } from 'recharts';

export function ProjectDetail() {
  const { id } = useParams();
  const project = projects.find((p) => p.id === id);
  const projectMilestones = milestones.filter((m) => m.projectId === id);

  if (!project) {
    return (
      <div className="min-h-screen bg-gray-50 p-8">
        <div className="max-w-4xl mx-auto">
          <div className="bg-white rounded-lg border border-gray-200 p-8 text-center">
            <p className="text-gray-600">Project not found</p>
            <Link to="/" className="text-blue-600 hover:text-blue-800 mt-4 inline-block">
              Return to Dashboard
            </Link>
          </div>
        </div>
      </div>
    );
  }

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(amount);
  };

  const formatDate = (dateStr: string) => {
    return new Date(dateStr).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
    });
  };

  const budgetData = [
    { name: 'Used', value: project.budgetUsed, color: '#3b82f6' },
    { name: 'Remaining', value: project.budget - project.budgetUsed, color: '#e5e7eb' },
  ];

  const completedMilestones = projectMilestones.filter((m) => m.status === 'Completed').length;
  const milestoneProgress = projectMilestones.length > 0 
    ? Math.round((completedMilestones / projectMilestones.length) * 100)
    : 0;

  return (
    <div className="min-h-screen bg-gray-50 p-8">
      <div className="max-w-7xl mx-auto">
        {/* Back Button */}
        <Link
          to="/"
          className="inline-flex items-center text-sm text-gray-600 hover:text-gray-900 mb-6"
        >
          <ArrowLeft className="w-4 h-4 mr-1" />
          Back to Dashboard
        </Link>

        {/* Header */}
        <div className="bg-white rounded-lg border border-gray-200 p-6 mb-6">
          <div className="flex items-start justify-between mb-4">
            <div>
              <h1 className="text-2xl font-semibold text-gray-900 mb-2">{project.title}</h1>
              <div className="flex items-center gap-4 text-sm text-gray-600">
                <div className="flex items-center">
                  <Calendar className="w-4 h-4 mr-1" />
                  {formatDate(project.startDate)} - {formatDate(project.endDate)}
                </div>
                <div className="flex items-center">
                  <DollarSign className="w-4 h-4 mr-1" />
                  {formatCurrency(project.budget)}
                </div>
              </div>
            </div>
            <StatusBadge status={project.status} />
          </div>
        </div>

        {/* Project Description */}
        <div className="bg-white rounded-lg border border-gray-200 p-6 mb-6">
          <h2 className="text-lg font-semibold text-gray-900 mb-3">Project Description</h2>
          <p className="text-gray-600 leading-relaxed">{project.description}</p>
        </div>

        {/* Milestone Progress */}
        <div className="bg-white rounded-lg border border-gray-200 p-6 mb-6">
          <h2 className="text-lg font-semibold text-gray-900 mb-4">Milestone Progress</h2>
          <div className="flex items-center mb-2">
            <div className="flex-1 bg-gray-200 rounded-full h-4 mr-4">
              <div
                className="bg-green-600 h-4 rounded-full transition-all duration-500"
                style={{ width: `${milestoneProgress}%` }}
              ></div>
            </div>
            <span className="text-sm font-medium text-gray-700">{milestoneProgress}% Complete</span>
          </div>
          <p className="text-sm text-gray-600">
            {completedMilestones} of {projectMilestones.length} milestones completed
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
          {/* Impact Metrics */}
          <div className="bg-white rounded-lg border border-gray-200 p-6">
            <h2 className="text-lg font-semibold text-gray-900 mb-4">Environmental Impact</h2>
            <div className="grid grid-cols-2 gap-4">
              <div className="bg-green-50 rounded-lg p-4 border border-green-100">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm font-medium text-gray-700">CO₂ Reduced</span>
                  <Leaf className="w-5 h-5 text-green-600" />
                </div>
                <div className="text-2xl font-semibold text-gray-900">
                  {project.impactMetrics.co2Reduced.toLocaleString()}
                  <span className="text-sm font-normal text-gray-600 ml-1">tons</span>
                </div>
              </div>

              <div className="bg-green-50 rounded-lg p-4 border border-green-100">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm font-medium text-gray-700">Trees Planted</span>
                  <TreePine className="w-5 h-5 text-green-600" />
                </div>
                <div className="text-2xl font-semibold text-gray-900">
                  {project.impactMetrics.treesPlanted.toLocaleString()}
                </div>
              </div>

              <div className="bg-blue-50 rounded-lg p-4 border border-blue-100">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm font-medium text-gray-700">Energy Saved</span>
                  <Zap className="w-5 h-5 text-blue-600" />
                </div>
                <div className="text-2xl font-semibold text-gray-900">
                  {project.impactMetrics.energySaved.toLocaleString()}
                  <span className="text-sm font-normal text-gray-600 ml-1">kWh</span>
                </div>
              </div>

              <div className="bg-purple-50 rounded-lg p-4 border border-purple-100">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm font-medium text-gray-700">People Impacted</span>
                  <Users className="w-5 h-5 text-purple-600" />
                </div>
                <div className="text-2xl font-semibold text-gray-900">
                  {project.impactMetrics.peopleImpacted.toLocaleString()}
                </div>
              </div>
            </div>
          </div>

          {/* Budget Usage Chart */}
          <div className="bg-white rounded-lg border border-gray-200 p-6">
            <h2 className="text-lg font-semibold text-gray-900 mb-4">Budget Usage</h2>
            <div className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={budgetData}
                    cx="50%"
                    cy="50%"
                    innerRadius={60}
                    outerRadius={90}
                    paddingAngle={2}
                    dataKey="value"
                  >
                    {budgetData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Pie>
                  <Tooltip
                    formatter={(value: number) => formatCurrency(value)}
                  />
                  <Legend />
                </PieChart>
              </ResponsiveContainer>
            </div>
            <div className="mt-4 space-y-2">
              <div className="flex justify-between text-sm">
                <span className="text-gray-600">Budget Used:</span>
                <span className="font-medium text-gray-900">{formatCurrency(project.budgetUsed)}</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-gray-600">Total Budget:</span>
                <span className="font-medium text-gray-900">{formatCurrency(project.budget)}</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-gray-600">Remaining:</span>
                <span className="font-medium text-gray-900">
                  {formatCurrency(project.budget - project.budgetUsed)}
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* Milestones List */}
        <div className="bg-white rounded-lg border border-gray-200">
          <div className="p-6 border-b border-gray-200">
            <h2 className="text-lg font-semibold text-gray-900">Milestones</h2>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-gray-50 border-b border-gray-200">
                <tr>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Title
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Due Date
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Status
                  </th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {projectMilestones.map((milestone) => (
                  <tr key={milestone.id} className="hover:bg-gray-50">
                    <td className="px-6 py-4 text-sm font-medium text-gray-900">
                      {milestone.title}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-600">
                      {formatDate(milestone.dueDate)}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <StatusBadge status={milestone.status} size="sm" />
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
}
