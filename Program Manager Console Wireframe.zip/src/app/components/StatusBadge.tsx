import { ProjectStatus, MilestoneStatus } from '../data/mockData';

interface StatusBadgeProps {
  status: ProjectStatus | MilestoneStatus;
  size?: 'sm' | 'md';
}

export function StatusBadge({ status, size = 'md' }: StatusBadgeProps) {
  const getStatusColor = (status: ProjectStatus | MilestoneStatus) => {
    switch (status) {
      case 'Active':
      case 'Completed':
        return 'bg-green-100 text-green-800 border-green-200';
      case 'In Progress':
        return 'bg-blue-100 text-blue-800 border-blue-200';
      case 'Delayed':
        return 'bg-red-100 text-red-800 border-red-200';
      case 'Planned':
        return 'bg-gray-100 text-gray-800 border-gray-200';
      default:
        return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  const sizeClasses = size === 'sm' ? 'px-2 py-0.5 text-xs' : 'px-3 py-1 text-sm';

  return (
    <span
      className={`inline-flex items-center rounded-full border font-medium ${getStatusColor(
        status
      )} ${sizeClasses}`}
    >
      {status}
    </span>
  );
}
