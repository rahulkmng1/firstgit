import { createBrowserRouter } from 'react-router';
import { Layout } from './components/Layout';
import { Dashboard } from './components/Dashboard';
import { ProjectDetail } from './components/ProjectDetail';
import { Milestones } from './components/Milestones';
import { Impact } from './components/Impact';

export const router = createBrowserRouter([
  {
    path: '/',
    Component: Layout,
    children: [
      { index: true, Component: Dashboard },
      { path: 'projects/:id', Component: ProjectDetail },
      { path: 'milestones', Component: Milestones },
      { path: 'impact', Component: Impact },
    ],
  },
]);