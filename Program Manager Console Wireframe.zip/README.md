
  # Program Manager Console Wireframe

  This is a code bundle for Program Manager Console Wireframe. The original project is available at https://www.figma.com/design/veyPx23sNNa5Nz5yIwdHi4/Program-Manager-Console-Wireframe.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  